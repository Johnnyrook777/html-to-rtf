module.exports = [
  { propertyName: 'color', allowed: true },
  { propertyName: 'font-size', allowed: true },
  { propertyName: 'text-align', allowed: true },
  { propertyName: 'background', allowed: false }
];