const htmlToRtf = require('./app/src/rtf/rtf.class');
// htmlToRtf.saveInFolderFiles(rtf.convertHtmlToRtf(htmlOfExample));
module.exports = new htmlToRtf();